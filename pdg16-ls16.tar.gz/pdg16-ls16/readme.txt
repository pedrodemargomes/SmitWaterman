Entrada:
<tamanho(seqA)> <tamanho(seqB)>
<seqA>
<seqB>

